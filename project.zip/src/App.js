 //회사 위치 정보 google api

import './App.css';
import GoogleMap  from '../src/map/map'
import Schedule from '../src/schedule/schedule';
import Vacation from '../src/vacation/vacation'
import Community from '../src/community/community'
import Announcement from '../src/announcement/announcement'
import Attend from '../src/attend/attend'
import Setting from '../src/setting/setting'
import Calculator from '../src/calculator/calculator';
import Money from '../src/money/money';
import Profiles from '../src/data/data'
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    
    <div><h1>Welcome to the Main page</h1>
    <h2> 제발 뭐할지 좀 알려줘</h2>
    {/* <GoogleMap onLoad={map => {
                const bounds = new window.google.maps.LatLngBounds();
    map.fitBounds(bounds);
  }}
  onUnmount={() => {
    // do your stuff before map is unmounted
  }}/> */}

  <BrowserRouter>
    <Routes>
      {/* 위에서부터 근무 일정, 출퇴근 기록, 휴가 관리, 근태정산, 급여,회사설정 */}
      {/* <Route path="/" element = {<Main />}></Route>
      이건 main page임  */}
      <Route path="/todaySchedule" element = {<Schedule/>}></Route>
      <Route path="/attend" element = {<Attend/>}></Route>
      <Route path="/vacation" element = {<Vacation/>}></Route>
      <Route path="/calculator" element = {<Calculator/>}></Route>
      <Route path="/money" element = {<Money/>}></Route>
      <Route path="/setting" element = {<Setting/>}></Route>
      
      <Route path="/map" element = {<GoogleMap></GoogleMap>}>{Show}</Route>
      
      

    </Routes>

    <Routes> 
      {/* 위에서부터 프로필, 게시판, 공지사항 */}
      <Route path='/userprofile' element = {<Profiles></Profiles>}></Route>
      <Route path='/community' element = {<Community></Community>}></Route>
      <Route path='/announcement' element = {<Announcement></Announcement>}></Route>
    </Routes>
  </BrowserRouter>
  {/* <Route path="*" element={ <div>없는페이지임 똑바로 안칠래!!</div> } /> */}
  <h2><table>
    {/* <Profiles></Profiles> */}
    </table></h2>
  
  
  </div>
    )
  }
export default App;
