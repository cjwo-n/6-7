function Calculator(){
    return(
        <div>근태 정산 페이지</div>
    )
}


export default Calculator;