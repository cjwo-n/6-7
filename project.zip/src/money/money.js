function Money (){
    return(
        <div>월급 주세요</div>
    )
}
export default Money;