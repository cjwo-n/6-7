
function Community(){
    return(
        <div>회사 게시판 페이지</div>
    )
}


export default Community;