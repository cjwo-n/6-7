import React from 'react'
import '../schedule/schedule.css'

// function Id (){
//     //const maxLength = Schedule.input.maxLength
//     if(maxLength > 8){
//         alert('8글자를 초과 했습니다')
//     }
// }

function Schedule(){
    return(
        <div>
            <div>Community</div>
            <form>
                <input
                    type='id'
                    placeholder='id 또는 코드를 입력하세요'
                    minLength={4}
                    maxLength={8}
                    style={{width:'500px', height:'30px', fontSize:'20px'}}>
                        {/* <Id></Id> */}
                </input>
                
                <br/>
                <input
                    type='password'
                    placeholder='비밀번호를 입력하세요'
                    minLength={4}
                    maxLength={8}
                    style={{width:'500px', height:'30px', fontSize:'20px'}}>
                    
                </input>
                
                <br/>
                <input 
                    type='date' 
                    placeholder='날짜 입력'
                    style={{height:'30px',fontSize:'20px'}}>
                </input>
                <br/>
                <button 
                    type='submit'
                    style={{height:'35px',fontSize:'20px'}}
                >조회하기
                </button>

                
            </form>
            
            
        </div>
    )
}

export default Schedule;