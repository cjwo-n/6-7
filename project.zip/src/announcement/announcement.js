function Announcement(){
    return(
        <div>공지사항 페이지</div>
    )
}


export default Announcement;