
function Vacation(){
    return(
        <div> 휴가 아직 미구현입니다^^;</div>
    )
}


export default Vacation;