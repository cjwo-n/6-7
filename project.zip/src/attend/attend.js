function Attend(){
    return(
        <div>출퇴근 페이지</div>
    )
}


export default Attend;