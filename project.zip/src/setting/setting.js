function Setting(){
    return(
        <div>회사 설정 페이지</div>
    )
}


export default Setting;